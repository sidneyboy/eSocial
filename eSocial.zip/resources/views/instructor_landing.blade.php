@extends('layouts.instructor')

@section('main-content')
    <div class="row">
        <div class="col-md-6">

        </div>
        <div class="col-md-6">

        </div>
    </div>
   
@endsection
