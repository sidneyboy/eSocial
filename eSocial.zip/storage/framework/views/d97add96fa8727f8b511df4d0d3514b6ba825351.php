

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="row">
        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
                    <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">
                        <div class="row">
                            <div class="col-md-6">
                                <?php echo e($data->course_type->course_type); ?> -
                                <?php echo e($data->course_title); ?>

                            </div>
                            <div class="col-md-6">
                                Comments <span class="badge badge-primary">New <?php echo e(count($data->comments_count)); ?></span>
                            </div>
                        </div>
                    </div>
                    <a href="<?php echo e(url('instructor_show_chapter', ['course_id' => $data->id])); ?>">
                        <img class="card-img-top" style="border-radius: 0px;"
                            src="<?php echo e(asset('/storage/' . $data->image_template)); ?>" alt="Card image cap">
                    </a>
                    <div class="card-body">
                        <p style="text-align: justify"><?php echo e($data->course_description); ?></p>
                    </div>
                    <div class="card-footer">
                        <div class="row">
                            <div class="col-md-12" style="margin-bottom: 10px;">
                                <a href="<?php echo e(url('instructor_add_course_phase_2', [$data->id])); ?>"
                                    class="btn btn-sm btn-block btn-info">ADD CHAPTER</a>
                            </div>
                            <div class="col-md-12">
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary btn-sm btn-block" data-toggle="modal"
                                    data-target="#exampleModal<?php echo e($data->id); ?>">
                                    ADD EXAM/QUIZ/ASSIGNMENT
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">ADD CHAPTER ACTIVITY</h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <form action="<?php echo e(route('instructor_chapter_add_quiz_or_exam')); ?>" method="get"
                                                enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-body">
                                                    <label>Add</label>
                                                    <select name="type" id="type" class="form-control" required>
                                                        <option value="" default>Select</option>
                                                        <option value="Chapter Exam">Chapter Exam</option>
                                                        <option value="Chapter Quiz">Chapter Quiz</option>
                                                        <option value="Chapter Assignment">Chapter Assignment</option>
                                                    </select>

                                                    <label>Chapter</label>
                                                    <select name="chapter_id" class="form-control" required>
                                                        <option value="" default>Select</option>
                                                        <?php $__currentLoopData = $data->course_chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($chapter->id); ?>">
                                                                <?php echo e($chapter->chapter_number); ?> - <?php echo e($chapter->title); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <input type="hidden" name="course_id" value="<?php echo e($data->id); ?>">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary"
                                                        data-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary btn-sm">Proceed</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_courses.blade.php ENDPATH**/ ?>