

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <br />
    <div class="card">
        <div class="card-header">Student Add To Do List <a href="<?php echo e(url('student_to_do_list')); ?>" class="btn btn-primary btn-sm float-right">List</a></div>
        <div class="card-body">
            <form action="<?php echo e(route('student_todo_process')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="date" class="form-control" required>

                    <label>Time</label>
                    <input type="time" name="time" class="form-control" required>

                    <label>To do</label>
                    <textarea name="todo" class="form-control" required></textarea>

                    <br />
                    <button class="btn btn-sm btn-success btn-block">Submit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_to_do.blade.php ENDPATH**/ ?>