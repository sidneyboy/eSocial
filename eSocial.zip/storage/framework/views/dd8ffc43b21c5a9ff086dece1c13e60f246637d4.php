

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('student_search_course')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search Subject" aria-label="Search Subject"
                        name="search_box" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        
                        <button class="input-group-text"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <h6 style="font-weight:bold;">LIST OF COURSES</h6>
    <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
                    <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">
                        <?php echo e($data->course_type->course_type); ?> -
                        <?php echo e($data->course_title); ?></div>
                    <img class="card-img-top" style="border-radius: 0px;"
                        src="<?php echo e(asset('/storage/' . $data->image_template)); ?>" alt="Card image cap">

                    <div class="card-body">
                        <p style="text-align: justify"><?php echo e($data->course_description); ?></p>
                    </div>
                    <div class="card-body">
                        <?php if($data->course_monitization == 'Free'): ?>
                            <form action="<?php echo e(route('student_enroll_course')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" value="<?php echo e($data->id); ?>" name="course_id">
                                <input type="hidden" value="<?php echo e($data->user_id); ?>" name="instructor_id">
                                <input type="hidden" value="<?php echo e($data->course_amount); ?>" name="amount">

                                <button class="btn btn-primary btn-block btn-sm" type="submit">Enroll</button>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(route('student_subscribed_course')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" value="<?php echo e($data->id); ?>" name="course_id">
                                <input type="hidden" value="<?php echo e($data->user_id); ?>" name="instructor_id">
                                <input type="hidden" value="<?php echo e($data->course_amount); ?>" name="amount">

                                <button class="btn btn-primary btn-block btn-sm" type="submit">Subscribed</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer" style="background-color:#141E30"">
                        <p style="color:white"> Instructor: <?php echo e($data->user->name); ?> <?php echo e($data->user->last_name); ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_course.blade.php ENDPATH**/ ?>