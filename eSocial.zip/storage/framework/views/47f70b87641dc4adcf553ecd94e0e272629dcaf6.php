

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="card" style="width: 100%;">
                <div class="card-header" style="font-weight: bold;">Add Course</div>
                <form action="<?php echo e(route('instructor_add_course_process')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Select Course:</label>
                            <select name="course_type" class="form-control" required>
                                <option value="" default>Select</option>
                                <?php $__currentLoopData = $course_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->course_type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <label>Course Title:</label>
                            <input type="text" class="form-control" name="course_title" required>

                            <label>Course Description:</label>
                            <textarea name="course_description" class="form-control required" cols="30" rows="5"></textarea>

                            <label>Monitization:</label>
                            <select name="course_monitization" id="course_monitization" class="form-control" required>
                                <option value="" default>Select</option>
                                <option value="Free">Free</option>
                                <option value="Monitize">Monitize</option>
                            </select>

                            <label>Course Image Template</label>
                            <input type="file" class="form-control" accept="image/*" required name="course_image_template">


                            <span id="course_amount" style="display: none">
                                <label>Amount:</label>
                                <input type="text" class="form-control" name="course_amount">
                            </span>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-sm btn-primary float-right">Next</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_add_course.blade.php ENDPATH**/ ?>