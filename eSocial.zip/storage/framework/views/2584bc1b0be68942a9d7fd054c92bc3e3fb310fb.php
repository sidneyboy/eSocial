

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Student Enrolled On Your Courses</div>
        <div class="card-body">
            <div class="table table-responsive">
                <table class="table table-bordered table-hover table-sm" id="example">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Email</th>
                            <th>Course</th>
                            <th>Course Type</th>
                            <th>Enrolled</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $enrolled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(url('instructor_student_logs', [
                                        'student_id' => $data->student_id,
                                        'course_id' => $data->course_id,
                                    ])); ?>"
                                        target="_blank"><?php echo e($data->student->last_name); ?> <?php echo e($data->student->name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($data->student->email); ?></td>
                                <td><?php echo e($data->course->course_title); ?></td>
                                <td><?php echo e($data->course->course_type->course_type); ?></td>
                                <td><?php echo e(date('F j, Y', strtotime($data->created_at))); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col-md-4">
                    <a href="<?php echo e(url('instructor_view_assignment_score',['type' => 'assignment'])); ?>" class="btn btn-block btn-primary btn-sm">View All Student Assignment Score</a>
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(url('instructor_view_assignment_score',['type' => 'quiz'])); ?>" class="btn btn-block btn-primary btn-sm">View All Student Quiz Score</a>
                </div>
                <div class="col-md-4">
                    <a href="<?php echo e(url('instructor_view_assignment_score',['type' => 'exam'])); ?>" class="btn btn-block btn-primary btn-sm">View All Student Exam Score</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_list_of_students.blade.php ENDPATH**/ ?>