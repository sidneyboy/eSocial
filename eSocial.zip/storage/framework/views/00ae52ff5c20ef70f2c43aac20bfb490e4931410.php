

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <h6 style="font-weight: bold;">ENROLLED COURSES</h6>
    <?php if(isset($course)): ?>
        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
                        <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">
                            <?php echo e($data->course_type->course_type); ?> -
                            <?php echo e($data->course_title); ?></div>
                        <a href="<?php echo e(url('student_show_course_chapter', ['course_id' => $data->id])); ?>">
                            <img class="card-img-top" style="border-radius: 0px;"
                            src="<?php echo e(asset('/storage/' . $data->image_template)); ?>" alt="Card image cap">
                        </a>
                        <div class="card-body">
                            <p style="text-align: justify"><?php echo e($data->course_description); ?></p>
                        </div>
                        
                        <div class="card-footer" style="background-color:#141E30"">
                            <p style="color:white"> Instructor: <?php echo e($data->user->name); ?> <?php echo e($data->user->last_name); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_enrolled_courses.blade.php ENDPATH**/ ?>