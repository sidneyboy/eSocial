

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="card" style="width: 100%;">
                <div class="card-header" style="font-weight: bold;">Chapter Exam</div>
                <form action="<?php echo e(route('instructor_add_course_exam_process')); ?>" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Exam Title</label>
                            <input type="text" name="title" required class="form-control">

                            <label>Number of questions</label>
                            <input type="number" min="0" name="number_of_questions" class="form-control" required>

                            <label>Question Type</label>
                            <select class="form-control" id="question_type" name="question_type" required name="question_type">
                                <option value="" default>Select</option>
                                <option value="Enumeration">Enumeration</option>
                                <option value="Multitple Choice">Multitple Choice</option>
                                <option value="Identification">Identification</option>
                                <option value="Matching Type">Matching Type</option>
                            </select>

                            
                            <label>Certificate</label>
                            <input type="file" name="certificate" class="form-control" required accept="application/*">

                            <input type="hidden" value="<?php echo e($course_id); ?>" name="course_id">
                            <input type="hidden" value="<?php echo e($course_chapter_id); ?>" name="course_chapter_id">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-sm btn-primary float-right">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_add_course_exam.blade.php ENDPATH**/ ?>