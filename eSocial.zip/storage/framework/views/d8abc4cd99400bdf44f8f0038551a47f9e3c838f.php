<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Student</title>
</head>

<body>
    <br />
    <div class="container">
        <?php $__currentLoopData = $assignment_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header">
                    <span style="text-transform: uppercase;font-weight:bold;"><?php echo e($type); ?></span>
                    <a href="<?php echo e(url('student_taken_submit', ['taken_id' => $taken_id])); ?>"
                        class="float-right btn-sm btn btn-warning">Finish</a>
                </div>
                <div class="card-header">
                    <?php if($question->question_type != 'Matching Type'): ?>
                        Question: <span class="float-right"><?php echo e($question->score); ?> Points</span> <br />
                        <?php echo e($question->question); ?>

                    <?php else: ?>
                        Matching Type
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <?php if($status != 'answered'): ?>
                            <?php if($question->question_type == 'Enumeration'): ?>
                                <?php
                                    $explode = explode('|', $question->answer);
                                ?>
                                <ul class="list-group">
                                    <input type="hidden" id="question_answer" value="<?php echo e($question->answer); ?>">
                                    <?php $__currentLoopData = $explode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item">
                                            <input type="text" name="answer[]" class="form-control">
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                            <?php elseif($question->question_type == 'Multitple Choice'): ?>
                                <input type="hidden" id="question_answer" value="<?php echo e($question->answer); ?>">

                                <?php if($type == 'assignment'): ?>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_a"><?php echo e($question->assignment_details->choice_a); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_b"><?php echo e($question->assignment_details->choice_b); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_c"><?php echo e($question->assignment_details->choice_c); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_d"><?php echo e($question->assignment_details->choice_d); ?></label>
                                    </div>
                                    <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                                <?php elseif($type == 'quiz'): ?>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_a"><?php echo e($question->quiz_details->choice_a); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_b"><?php echo e($question->quiz_details->choice_b); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_c"><?php echo e($question->quiz_details->choice_c); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_d"><?php echo e($question->quiz_details->choice_d); ?></label>
                                    </div>
                                    <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                                <?php elseif($type == 'exam'): ?>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_a"><?php echo e($question->exam_details->choice_a); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_b"><?php echo e($question->exam_details->choice_b); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_c"><?php echo e($question->exam_details->choice_c); ?></label>
                                    </div>
                                    <div class="radio">
                                        <label><input type="radio" name="student_answer" class="student_answer"
                                                value="choice_d"><?php echo e($question->exam_details->choice_d); ?></label>
                                    </div>
                                    <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                                <?php endif; ?>
                            <?php elseif($question->question_type == 'Identification'): ?>
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <input type="text" class="form-control" id="answer" required>
                                    </li>
                                </ul>
                                <input type="hidden" id="question_answer" value="<?php echo e($question->answer); ?>">
                                <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                            <?php elseif($question->question_type == 'Matching Type'): ?>
                                <?php
                                    $match_answer = explode('|', $question->answer);
                                    $match_question = explode('|', $question->question);
                                ?>
                                <ul class="list-group">
                                    <?php for($i = 0; $i < count($match_answer); $i++): ?>
                                        <?php echo e($i + 1); ?>. <li class="list-group-item">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <?php echo e($match_question[$i]); ?>

                                                </div>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control" name="answer[]"
                                                        required>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endfor; ?>
                                </ul>
                                <br />
                                <input type="hidden" id="question_answer" value="<?php echo e($question->answer); ?>">
                                <input type="hidden" id="question_type" value="<?php echo e($question->question_type); ?>">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        Choices</li>
                                    <?php if($type == 'assignment'): ?>
                                        <?php $__currentLoopData = $question->assignment_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php echo e($match_choices->choices); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php elseif($type == 'quiz'): ?>
                                        <?php $__currentLoopData = $question->quiz_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php echo e($match_choices->choices); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php elseif($type == 'exam'): ?>
                                        <?php $__currentLoopData = $question->exam_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="list-group-item">
                                                <?php echo e($match_choices->choices); ?>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            <?php endif; ?>
                        <?php else: ?>
                            <h3><span class="badge badge-success">Answer Submitted</span></h3>
                        <?php endif; ?>
                        <br />

                        <input type="hidden" id="type" value="<?php echo e($type); ?>">
                        <input type="hidden" id="question_id" value="<?php echo e($question->id); ?>">
                        <input type="hidden" id="taken_id" value="<?php echo e($taken_id); ?>">
                        
                        <button id="submit" class="btn btn-sm btn-success btn-block">Submit Answer</button>
                    </div>
                </div>
                <div class="card-footer">
                    <div class="float-right">
                        <?php echo e($assignment_question->links()); ?>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br />
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#submit").click(function() {
            $('#submit').hide();
            if ($('#question_type').val() == 'Enumeration') {
                var student_answer = $("input[name='answer[]']").map(function() {
                    return $(this).val();
                }).get();
                var taken_id = $('#taken_id').val();
                var question_type = $('#question_type').val();
                var type = $('#type').val();
                var question_answer = $('#question_answer').val();
                var question_id = $('#question_id').val();
                $.ajax({
                    type: "POST",
                    url: "/student_taken_process",
                    data: 'taken_id=' + taken_id + '&student_answer=' +
                        student_answer + '&question_type=' +
                        question_type + '&type=' +
                        type + '&question_answer=' +
                        question_answer + '&question_id=' +
                        question_id,
                    success: function(data) {
                        Swal.fire(
                            'Good job!',
                            'Answer Submitted',
                            'success',
                        )
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            } else if ($('#question_type').val() == 'Multitple Choice') {
                var taken_id = $('#taken_id').val();
                var student_answer = $(".student_answer:checked").val();
                var question_type = $('#question_type').val();
                var type = $('#type').val();
                var question_answer = $('#question_answer').val();
                var question_id = $('#question_id').val();
                $.ajax({
                    type: "POST",
                    url: "/student_taken_process",
                    data: 'taken_id=' + taken_id + '&student_answer=' +
                        student_answer + '&question_type=' +
                        question_type + '&type=' +
                        type + '&question_answer=' +
                        question_answer + '&question_id=' +
                        question_id,
                    success: function(data) {
                        Swal.fire(
                            'Good job!',
                            'Answer Submitted',
                            'success',
                        )
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            } else if ($('#question_type').val() == 'Identification') {
                var student_answer = $('#answer').val();
                var taken_id = $('#taken_id').val();
                var question_type = $('#question_type').val();
                var type = $('#type').val();
                var question_answer = $('#question_answer').val();
                var question_id = $('#question_id').val();
                $.ajax({
                    type: "POST",
                    url: "/student_taken_process",
                    data: 'taken_id=' + taken_id + '&student_answer=' +
                        student_answer + '&question_type=' +
                        question_type + '&type=' +
                        type + '&question_answer=' +
                        question_answer + '&question_id=' +
                        question_id,
                    success: function(data) {
                        Swal.fire(
                            'Good job!',
                            'Answer Submitted',
                            'success',
                        )
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            } else if ($('#question_type').val() == 'Matching Type') {
                var student_answer = $("input[name='answer[]']").map(function() {
                    return $(this).val();
                }).get();
                var taken_id = $('#taken_id').val();
                var question_type = $('#question_type').val();
                var type = $('#type').val();
                var question_answer = $('#question_answer').val();
                var question_id = $('#question_id').val();
                $.ajax({
                    type: "POST",
                    url: "/student_taken_process",
                    data: 'taken_id=' + taken_id + '&student_answer=' +
                        student_answer + '&question_type=' +
                        question_type + '&type=' +
                        type + '&question_answer=' +
                        question_answer + '&question_id=' +
                        question_id,
                    success: function(data) {
                        Swal.fire(
                            'Good job!',
                            'Answer Submitted',
                            'success',
                        )
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });
            }
        });
    </script>

    

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"
        integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous">
    </script>
    -->
</body>

</html>
<?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_show_taken_page.blade.php ENDPATH**/ ?>