

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('student_enrolled_search_course')); ?>">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Search Subject" aria-label="Search Subject"
                        name="search_box" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <span class="input-group-text" id="basic-addon2"><i class="bi bi-search"></i></span>
                    </div>
                </div>

            </form>
        </div>
    </div>
    <?php $__currentLoopData = $course_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
          <div class="col-md-12">
              <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
                  <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">
                      <?php echo e($data->course_type->course_type); ?> -
                      <?php echo e($data->course_title); ?></div>
                  <img class="card-img-top" style="border-radius: 0px;"
                      src="<?php echo e(asset('/storage/' . $data->image_template)); ?>" alt="Card image cap">
                  <div class="card-body">
                      <p style="text-align: justify"><?php echo e($data->course_description); ?></p>
                  </div>
                  <div class="card-body">
                      <button class="btn btn-primary btn-sm btn-block"
                          style="border-radius: 0px;border:0px;" type="button" data-toggle="collapse"
                          data-target="#collapseExample<?php echo e($data->id); ?>" aria-expanded="false"
                          aria-controls="collapseExample<?php echo e($data->id); ?>">
                          Show
                      </button>
                      <div class="collapse" id="collapseExample<?php echo e($data->id); ?>">
                          <div class="card card-body">
                              <ul class="list-group">
                                  <li class="list-group-item">
                                      <!-- Button trigger modal -->
                                      <button type="button" class="btn btn-primary btn-block btn-sm"
                                          style="text-decoration: none;" data-toggle="modal"
                                          data-target="#exampleModal_show_comment<?php echo e($data->id); ?>">
                                          View Comment
                                      </button>

                                      <!-- Modal -->
                                      <div class="modal fade"
                                          id="exampleModal_show_comment<?php echo e($data->id); ?>"
                                          tabindex="-1" role="dialog"
                                          aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog" role="document">
                                              <div class="modal-content">
                                                  <div class="modal-header">
                                                      <h5 class="modal-title" id="exampleModalLabel">
                                                          Comments</h5>
                                                      <button type="button" class="close"
                                                          data-dismiss="modal" aria-label="Close">
                                                          <span aria-hidden="true">&times;</span>
                                                      </button>
                                                  </div>
                                                  <form action="<?php echo e(route('student_comment_process')); ?>"
                                                      method="post">
                                                      <?php echo csrf_field(); ?>
                                                      <div class="modal-body">
                                                          <div id="table-wrapper">
                                                              <div id="table-scroll">
                                                                  <table>
                                                                      <tbody>
                                                                          <?php $__currentLoopData = $data->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                              <tr>
                                                                                  <td>
                                                                                      <?php if($comment_details->user->user_type == 'Student'): ?>
                                                                                          <div class="alert alert-success"
                                                                                              role="alert">
                                                                                              <h6
                                                                                                  class="alert-heading">
                                                                                                  <?php echo e($comment_details->user->name); ?>

                                                                                                  <?php echo e($comment_details->user->last_name); ?>

                                                                                                  -
                                                                                                  <?php echo e($comment_details->user->user_type); ?>

                                                                                              </h6>
                                                                                              <hr>
                                                                                              <p><?php echo e($comment_details->comment); ?>

                                                                                              </p>
                                                                                              <hr>
                                                                                              <p
                                                                                                  class="mb-0">
                                                                                                  <?php echo e(date('F j, Y H:i a', strtotime($comment_details->created_at))); ?>

                                                                                              </p>
                                                                                          </div>
                                                                                      <?php else: ?>
                                                                                          <div class="alert alert-warning"
                                                                                              role="alert">
                                                                                              <h6
                                                                                                  class="alert-heading">
                                                                                                  <?php echo e($comment_details->user->name); ?>

                                                                                                  <?php echo e($comment_details->user->last_name); ?>

                                                                                                  -
                                                                                                  <?php echo e($comment_details->user->user_type); ?>

                                                                                              </h6>
                                                                                              <hr>
                                                                                              <p><?php echo e($comment_details->comment); ?>

                                                                                              </p>
                                                                                              <hr>
                                                                                              <p
                                                                                                  class="mb-0">
                                                                                                  <?php echo e(date('F j, Y H:i a', strtotime($comment_details->created_at))); ?>

                                                                                              </p>
                                                                                          </div>
                                                                                      <?php endif; ?>
                                                                                      <input
                                                                                          type="hidden"
                                                                                          name="comment_details[]"
                                                                                          value="<?php echo e($comment_details->id); ?>">
                                                                                  </td>
                                                                              </tr>
                                                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                      </tbody>
                                                                  </table>
                                                              </div>
                                                          </div>
                                                      </div>
                                                      <div class="modal-body">
                                                          <label>Write Comment</label>
                                                          <textarea name="comment" class="form-control"></textarea>
                                                          <input type="hidden" name="course_id"
                                                              value="<?php echo e($data->id); ?>">

                                                      </div>
                                                      <div class="modal-footer">
                                                          <button type="button"
                                                              class="btn btn-secondary btn-sm"
                                                              data-dismiss="modal">Close</button>
                                                          <button type="submit"
                                                              class="btn btn-primary btn-sm">Submit</button>
                                                      </div>
                                                  </form>
                                              </div>
                                          </div>
                                      </div>
                                  </li>
                                  <li class="list-group-item">
                                      <a href="<?php echo e(url('student_show_exam', ['course_id' => $data->id])); ?>"
                                          class="btn btn-sm btn-primary btn-block">Open Exam</a>
                                  </li>
                                  <li class="list-group-item">
                                      <a href="<?php echo e(url('student_show_pdf_file', ['course_id' => $data->id])); ?>"
                                          class="btn btn-sm btn-primary btn-block">Open Files</a>
                                  </li>
                                  <li class="list-group-item">
                                      <a href="<?php echo e(url('student_show_image_file', ['course_id' => $data->id])); ?>"
                                          class="btn btn-sm btn-primary btn-block">Open Images</a>
                                  </li>
                                  <li class="list-group-item">
                                      <a href="<?php echo e(url('student_show_video', ['course_id' => $data->id])); ?>"
                                          class="btn btn-sm btn-primary btn-block">Open Videos</a>
                                  </li>
                              </ul>
                          </div>
                      </div>
                  </div>
                  <div class="card-footer" style="background-color:#141E30"">
                      <p style="color:white"> Instructor: <?php echo e($data->user->name); ?>

                          <?php echo e($data->user->last_name); ?></p>
                  </div>
              </div>
          </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_enrolled_search_course.blade.php ENDPATH**/ ?>