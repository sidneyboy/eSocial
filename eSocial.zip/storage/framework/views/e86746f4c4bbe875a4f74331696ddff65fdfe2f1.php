

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>


    <?php if(isset($course_chapter_next_chapter)): ?>
        <?php $__currentLoopData = $course_chapter_next_chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
                <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">Chapter
                    <?php echo e($data->chapter_number); ?></div>
                
                <img class="card-img-top" style="border-radius: 0px;" src="<?php echo e(asset('/storage/' . $data->thumbnail)); ?>"
                    alt="Card image cap">
                
                <div class="card-body">
                    <?php echo e($data->content); ?>

                </div>
                <div class="card-footer" style="font-weight: bold;background-color:#141E30;">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-danger btn-sm btn-info btn-block" data-toggle="modal"
                        data-target="#exampleModal<?php echo e($data->id); ?>">
                        Material
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Chapter Conten</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="accordion" id="accordionExample">
                                        <div class="card">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link btn-block text-left" type="button"
                                                        data-toggle="collapse" data-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        Materials
                                                    </button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                                data-parent="#accordionExample">
                                                <div class="card-body">
                                                    <table class="table ">
                                                        <thead>
                                                            <tr>
                                                                <th>File Type</th>
                                                                <th>Chapter File</th>
                                                                
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $data->course_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <?php if($details->file_type == 'image'): ?>
                                                                        <td><?php echo e($details->file_type); ?></td>
                                                                        <td>
                                                                            <?php if($details->status != 'disabled'): ?>
                                                                                <?php if($details->file_type == 'image'): ?>
                                                                                    <a href="<?php echo e(url('student_show_image_file', [
                                                                                        'course_details_id' => $details->id,
                                                                                        'course_id' => $details->course_id,
                                                                                        'course_chapter_id' => $details->course_chapter_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-sm btn-primary btn-block">show</a>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    <?php elseif($details->file_type == 'video'): ?>
                                                                        <td><?php echo e($details->file_type); ?></td>
                                                                        <td>
                                                                            <?php if($details->status != 'disabled'): ?>
                                                                                <?php if($details->file_type == 'video'): ?>
                                                                                    <a href="<?php echo e(url('student_show_video', [
                                                                                        'course_details_id' => $details->id,
                                                                                        'course_id' => $details->course_id,
                                                                                        'course_chapter_id' => $details->course_chapter_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-primary btn-block">show</a>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    <?php elseif($details->file_type == 'application'): ?>
                                                                        <td><?php echo e($details->file_type); ?></td>
                                                                        <td>
                                                                            <?php if($details->status != 'disabled'): ?>
                                                                                <?php if($details->file_type == 'application'): ?>
                                                                                    <a href="<?php echo e(url('student_show_pdf_file', [
                                                                                        'course_details_id' => $details->id,
                                                                                        'course_id' => $details->course_id,
                                                                                        // 'course_chapter_id' => $details->course_chapter_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-primary btn-block">show</a>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    <?php endif; ?>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="headingTwo">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link btn-block text-left collapsed"
                                                        type="button" data-toggle="collapse" data-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Assignment
                                                    </button>
                                                </h2>
                                            </div>
                                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                                data-parent="#accordionExample">
                                                <div class="card-body">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Title</th>
                                                                <th>Score</th>
                                                                <th>Percentage</th>
                                                                <th>Deadline</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $data->assignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($assignment->status != 'disabled'): ?>
                                                                    <tr>
                                                                        <td>
                                                                            <a
                                                                                href="<?php echo e(url('student_show_taken', [
                                                                                    'id' => $assignment->id,
                                                                                    'type' => 'assignment',
                                                                                ])); ?>"><?php echo e($assignment->title); ?></a>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($assignment->student_assignment_score): ?>
                                                                                <?php echo e($assignment->student_assignment_score->score); ?>/<?php echo e($assignment->student_assignment_score->total_points); ?>

                                                                                <?php
                                                                                    $percentage = ($assignment->student_assignment_score->score / $assignment->student_assignment_score->total_points) * 100;
                                                                                ?>
                                                                            <?php else: ?>
                                                                                <?php
                                                                                    $percentage = 0;
                                                                                ?>
                                                                                Not Taken
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php echo e(round($percentage, 2)); ?>%
                                                                        </td>
                                                                        <td><?php echo e(date('F j, Y', strtotime($assignment->deadline))); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="headingThree">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link btn-block text-left collapsed"
                                                        type="button" data-toggle="collapse" data-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        Quizes
                                                    </button>
                                                </h2>
                                            </div>
                                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                                data-parent="#accordionExample">
                                                <div class="card-body">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Quiz</th>
                                                                <th>Score</th>
                                                                <th>Percentage</th>
                                                                <th>Posted</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $data->course_quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($quiz->status != 'disabled'): ?>
                                                                    <tr>
                                                                        <td>
                                                                            <a
                                                                                href="<?php echo e(url('student_show_taken', [
                                                                                    'id' => $quiz->id,
                                                                                    'type' => 'quiz',
                                                                                ])); ?>"><?php echo e($quiz->quiz_title); ?></a>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($quiz->student_quiz_score): ?>
                                                                                <?php echo e($quiz->student_quiz_score->score); ?>/<?php echo e($quiz->student_quiz_score->total_points); ?>

                                                                                <?php
                                                                                    $percentage = ($quiz->student_quiz_score->score / $quiz->student_quiz_score->total_points) * 100;
                                                                                ?>
                                                                            <?php else: ?>
                                                                                <?php
                                                                                    $percentage = 0;
                                                                                ?>
                                                                                Not Taken
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td><?php echo e(date('F j, Y', strtotime($quiz->created_at))); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card">
                                            <div class="card-header" id="headingFour">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link btn-block text-left collapsed"
                                                        type="button" data-toggle="collapse" data-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Exam
                                                    </button>
                                                </h2>
                                            </div>
                                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                                data-parent="#accordionExample">
                                                <div class="card-body">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                                <th>Exam</th>
                                                                <th>Score</th>
                                                                <th>Percentage</th>
                                                                <th>Posted</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $data->exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($exam->status != 'disabled'): ?>
                                                                    <tr>
                                                                        <td>
                                                                            <a
                                                                                href="<?php echo e(url('student_show_taken', [
                                                                                    'id' => $exam->id,
                                                                                    'type' => 'exam',
                                                                                ])); ?>"><?php echo e($exam->title); ?></a>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($exam->student_exam_score): ?>
                                                                                <?php echo e($exam->student_exam_score->score); ?>/<?php echo e($exam->student_exam_score->total_points); ?>

                                                                                <?php
                                                                                    $percentage = ($exam->student_exam_score->score / $exam->student_exam_score->total_points) * 100;
                                                                                ?>
                                                                            <?php else: ?>
                                                                                <?php
                                                                                    $percentage = 0;
                                                                                ?>
                                                                                Not Taken
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php echo e(round($percentage, 2)); ?>%
                                                                        </td>
                                                                        <td><?php echo e(date('F j, Y', strtotime($exam->created_at))); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>


    <?php $__currentLoopData = $course_chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="width: 100%;margin-bottom:50px;background-color:gainsboro">
            <div class="card-header" style="font-weight: bold;background-color:#141E30;color:white">Chapter
                <?php echo e($data->chapter_number); ?></div>
            
            <img class="card-img-top" style="border-radius: 0px;" src="<?php echo e(asset('/storage/' . $data->thumbnail)); ?>"
                alt="Card image cap">
            
            <div class="card-body">
                <?php echo e($data->content); ?>

            </div>
            <div class="card-footer" style="font-weight: bold;background-color:#141E30;">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-danger btn-sm btn-info btn-block" data-toggle="modal"
                    data-target="#exampleModal<?php echo e($data->id); ?>">
                    Material
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Chapter Content</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="accordion" id="accordionExample">
                                    <div class="card">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link btn-block text-left" type="button"
                                                    data-toggle="collapse" data-target="#collapseOne"
                                                    aria-expanded="true" aria-controls="collapseOne">
                                                    Materials
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <table class="table ">
                                                    <thead>
                                                        <tr>
                                                            <th>File Type</th>
                                                            <th>Chapter File</th>
                                                            
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $data->course_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <?php if($details->file_type == 'image'): ?>
                                                                    <td><?php echo e($details->file_type); ?></td>
                                                                    <td>
                                                                        <?php if($details->status != 'disabled'): ?>
                                                                            <?php if($details->file_type == 'image'): ?>
                                                                                <a href="<?php echo e(url('student_show_image_file', [
                                                                                    'course_details_id' => $details->id,
                                                                                    'course_id' => $details->course_id,
                                                                                    'course_chapter_id' => $details->course_chapter_id,
                                                                                ])); ?>"
                                                                                    class="btn btn-sm btn-sm btn-primary btn-block">show</a>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                <?php elseif($details->file_type == 'video'): ?>
                                                                    <td><?php echo e($details->file_type); ?></td>
                                                                    <td>
                                                                        <?php if($details->status != 'disabled'): ?>
                                                                            <?php if($details->file_type == 'video'): ?>
                                                                                <a href="<?php echo e(url('student_show_video', [
                                                                                    'course_details_id' => $details->id,
                                                                                    'course_id' => $details->course_id,
                                                                                    'course_chapter_id' => $details->course_chapter_id,
                                                                                ])); ?>"
                                                                                    class="btn btn-sm btn-primary btn-block">show</a>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                <?php elseif($details->file_type == 'application'): ?>
                                                                    <td><?php echo e($details->file_type); ?></td>
                                                                    <td>
                                                                        <?php if($details->status != 'disabled'): ?>
                                                                            <?php if($details->file_type == 'application'): ?>
                                                                                <a href="<?php echo e(url('student_show_pdf_file', [
                                                                                    'course_details_id' => $details->id,
                                                                                    'course_id' => $details->course_id,
                                                                                ])); ?>"
                                                                                    class="btn btn-sm btn-primary btn-block">show</a>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                <?php endif; ?>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link btn-block text-left collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseTwo"
                                                    aria-expanded="false" aria-controls="collapseTwo">
                                                    Assignment
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>Title</th>
                                                            <th>Score</th>
                                                            <th>Percentage</th>
                                                            <th>Deadline</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $data->assignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($assignment->status != 'disabled'): ?>
                                                                <tr>
                                                                    <td>
                                                                        <a
                                                                            href="<?php echo e(url('student_show_taken', [
                                                                                'id' => $assignment->id,
                                                                                'type' => 'assignment',
                                                                            ])); ?>"><?php echo e($assignment->title); ?></a>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($assignment->student_assignment_score): ?>
                                                                            <?php echo e($assignment->student_assignment_score->score); ?>/<?php echo e($assignment->student_assignment_score->total_points); ?>

                                                                            <?php
                                                                                $percentage = ($assignment->student_assignment_score->score / $assignment->student_assignment_score->total_points) * 100;
                                                                            ?>
                                                                        <?php else: ?>
                                                                            <?php
                                                                                $percentage = 0;
                                                                            ?>
                                                                            Not Taken
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo e(round($percentage, 2)); ?>%
                                                                    </td>
                                                                    <td><?php echo e(date('F j, Y', strtotime($assignment->deadline))); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link btn-block text-left collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseThree"
                                                    aria-expanded="false" aria-controls="collapseThree">
                                                    Quizes
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <div class="table table-responsive">
                                                    <table class="table table-sm">
                                                        <thead>
                                                            <tr>
                                                                <th>Quiz</th>
                                                                <th>Score</th>
                                                                <th>Percentage</th>
                                                                <th>Posted</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $data->course_quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($quiz->status != 'disabled'): ?>
                                                                    <tr>
                                                                        <td>
                                                                            <a
                                                                                href="<?php echo e(url('student_show_taken', [
                                                                                    'id' => $quiz->id,
                                                                                    'type' => 'quiz',
                                                                                ])); ?>"><?php echo e($quiz->quiz_title); ?></a>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($quiz->student_quiz_score): ?>
                                                                                <?php echo e($quiz->student_quiz_score->score); ?>/<?php echo e($quiz->student_quiz_score->total_points); ?>

                                                                                <?php
                                                                                    $percentage = ($quiz->student_quiz_score->score / $quiz->student_quiz_score->total_points) * 100;
                                                                                ?>
                                                                            <?php else: ?>
                                                                                <?php
                                                                                    $percentage = 0;
                                                                                ?>
                                                                                Not Taken
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php echo e(round($percentage, 2)); ?>%
                                                                        </td>
                                                                        <td><?php echo e(date('F j, Y', strtotime($quiz->created_at))); ?>

                                                                        </td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-header" id="headingFour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link btn-block text-left collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseFour"
                                                    aria-expanded="false" aria-controls="collapseFour">
                                                    Exam
                                                </button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>Exam</th>
                                                            <th>Score</th>
                                                            <th>Percentage</th>
                                                            <th>Posted</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $data->exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($exam->status != 'disabled'): ?>
                                                                <tr>
                                                                    <td>
                                                                        <a
                                                                            href="<?php echo e(url('student_show_taken', [
                                                                                'id' => $exam->id,
                                                                                'type' => 'exam',
                                                                            ])); ?>"><?php echo e($exam->title); ?></a>
                                                                    </td>
                                                                    <td>
                                                                        <?php if($exam->student_exam_score): ?>
                                                                            <?php echo e($exam->student_exam_score->score); ?>/<?php echo e($exam->student_exam_score->total_points); ?>

                                                                            <?php
                                                                                $percentage = ($exam->student_exam_score->score / $exam->student_exam_score->total_points) * 100;
                                                                            ?>
                                                                        <?php else: ?>
                                                                            <?php
                                                                                $percentage = 0;
                                                                            ?>
                                                                            Not Taken
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php echo e(round($percentage, 2)); ?>%
                                                                    </td>
                                                                    <td><?php echo e(date('F j, Y', strtotime($exam->created_at))); ?>

                                                                    </td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm"
                                    data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <div class="card">
        <div class="card-header">Comments</div>
        <div class="card-body">
            <?php $__currentLoopData = $course->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="margin-bottom: 10px;">
                    <div class="card-header"><?php echo e($comments->user->last_name); ?> <?php echo e($comments->user->name); ?></div>
                    <div class="card-body"><?php echo e($comments->comment); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <form action="<?php echo e(route('student_comment_process')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label>Add Comment</label>
                <textarea name="comment" class="form-control" required></textarea>
                <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>">
                <br />
                <button class="btn btn-primary btn-sm float-right">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<script>
    $('#myTab button').on('click', function(event) {
        event.preventDefault()
        $(this).tab('show')
    })
</script>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_show_course_chapter.blade.php ENDPATH**/ ?>