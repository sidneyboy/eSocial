

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">Messages</div>
        <div class="card-body">
            <ul class="list-group">
                <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <button type="button" class="btn btn-primary btn-block" data-toggle="modal"
                            data-target="#exampleModal_direct_message<?php echo e($data->id); ?>">
                            Direct Message -
                            <?php echo e($data->name); ?> <?php echo e($data->last_name); ?> <span class="badge badge-light">
                                <?php echo e($count_message[$data->id]); ?>

                                
                                
                            </span>
                        </button>
                        <div class="modal fade" id="exampleModal_direct_message<?php echo e($data->id); ?>" tabindex="-1"
                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Direct Message</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('student_message_process')); ?>" method="post"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div id="table-wrapper">
                                                <div id="table-scroll">
                                                    <table>
                                                        <tbody>
                                                            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td>
                                                                        <?php if($dm->instructor_id == $data->id): ?>
                                                                            <?php if($dm->status != 'replied'): ?>
                                                                                <input type="hidden"
                                                                                    value="<?php echo e($dm->id); ?>"
                                                                                    name="dm_id[]">
                                                                            <?php endif; ?>
                                                                            <?php if($dm->user_typer == 'Student'): ?>
                                                                                <div class="alert alert-success"
                                                                                    role="alert">
                                                                                    <h6 class="alert-heading">
                                                                                        <?php echo e($dm->student->name); ?>

                                                                                        <?php echo e($dm->student->last_name); ?>


                                                                                    </h6>
                                                                                    <hr>
                                                                                    <p><?php echo e($dm->comment); ?>

                                                                                    </p>
                                                                                    <?php if($dm->file != null): ?>
                                                                                        <img src="<?php echo e(asset('/storage/' . $dm->file)); ?>"
                                                                                            class="img img-thumbnail"
                                                                                            alt="">
                                                                                    <?php endif; ?>
                                                                                    <hr>
                                                                                    <p class="mb-0">
                                                                                        <?php echo e(date('F j, Y H:i a', strtotime($dm->created_at))); ?>

                                                                                    </p>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <div class="alert alert-warning"
                                                                                    role="alert">
                                                                                    <h6 class="alert-heading">
                                                                                        <?php echo e($dm->instructor->name); ?>

                                                                                        <?php echo e($dm->instructor->last_name); ?>


                                                                                    </h6>
                                                                                    <hr>
                                                                                    <p><?php echo e($dm->comment); ?>

                                                                                    </p>
                                                                                    <?php if($dm->file != null): ?>
                                                                                        <img src="<?php echo e(asset('/storage/' . $dm->file)); ?>"
                                                                                            class="img img-thumbnail"
                                                                                            alt="">
                                                                                    <?php endif; ?>
                                                                                    <hr>
                                                                                    <p class="mb-0">
                                                                                        <?php echo e(date('F j, Y H:i a', strtotime($dm->created_at))); ?>

                                                                                    </p>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label>Write Message</label>
                                                <textarea name="comment" class="form-control"></textarea>
                                                <input type="hidden" value="<?php echo e($data->id); ?>" required name="instructor_id">

                                                <label>Attachment</label>
                                                <input type="file" class="form-control" accept="image/*,video/*"
                                                    name="message_file">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/student_direct_message.blade.php ENDPATH**/ ?>