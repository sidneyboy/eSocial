

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="row">
                <?php $__currentLoopData = $course_chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="card" style="margin-bottom:20px;">
                            <div class="card-header">Chapter <?php echo e($data->chapter_number); ?> - <?php echo e($data->title); ?></div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12"><?php echo e($data->content); ?></div>
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <button class="btn btn-info btn-sm btn-block" style="margin-bottom: 10px;"
                                                    type="button" data-toggle="collapse"
                                                    data-target="#collapseExampleattachments<?php echo e($data->id); ?>"
                                                    aria-expanded="false"
                                                    aria-controls="collapseExampleattachments<?php echo e($data->id); ?>">
                                                    CHAPTER ATTACHMENTS
                                                </button>
                                            </div>
                                            <div class="col-md-12">
                                                <button class="btn btn-info btn-sm btn-block" style="margin-bottom: 10px;"
                                                    type="button" data-toggle="collapse"
                                                    data-target="#collapseExampleexam<?php echo e($data->id); ?>"
                                                    aria-expanded="false"
                                                    aria-controls="collapseExampleexam<?php echo e($data->id); ?>">
                                                    CHAPTER QUIZ/EXAM
                                                </button>
                                            </div>
                                            <div class="col-md-12" style="overflow: scroll;height:250px;">
                                                <br />
                                                <div class="collapse" id="collapseExampleattachments<?php echo e($data->id); ?>">
                                                    <div class="card card-body">
                                                        <div class="table table-responsive">
                                                            <table class="table table-striped table-hover table-sm"
                                                                id="example">
                                                                <thead>
                                                                    <tr>
                                                                        <th>File Type</th>
                                                                        <th>Chapter File</th>
                                                                        <th>Created At</th>
                                                                        <th>Status</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $data->course_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <?php if($details->file_type == 'image'): ?>
                                                                                <td><?php echo e($details->file_type); ?></td>
                                                                                <td>
                                                                                    <?php if($details->file_type == 'image'): ?>
                                                                                        <a href="<?php echo e(url('instructor_show_image', [
                                                                                            'course_details_id' => $details->id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-sm btn-primary btn-block">show</a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e(date('F j, Y h:i a', strtotime($details->created_at))); ?>

                                                                                </td>
                                                                                <td>
                                                                                    <?php if($details->status == 'disabled'): ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-danger btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php else: ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-success btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                            <?php elseif($details->file_type == 'video'): ?>
                                                                                <td><?php echo e($details->file_type); ?></td>
                                                                                <td>
                                                                                    <?php if($details->file_type == 'video'): ?>
                                                                                        <a href="<?php echo e(url('instructor_show_video', ['course_details_id' => $details->id])); ?>"
                                                                                            class="btn btn-sm btn-primary btn-block">show</a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e(date('F j, Y h:i a', strtotime($details->created_at))); ?>

                                                                                </td>
                                                                                <td>
                                                                                    <?php if($details->status == 'disabled'): ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-danger btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php else: ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-success btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                            <?php elseif($details->file_type == 'application'): ?>
                                                                                <td><?php echo e($details->file_type); ?></td>
                                                                                <td>
                                                                                    <?php if($details->file_type == 'application'): ?>
                                                                                        <a href="<?php echo e(asset('/storage/' . $details->file)); ?>"
                                                                                            download
                                                                                            class="btn btn-block btn-primary btn-sm"><?php echo e($details->file); ?></a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                                <td><?php echo e(date('F j, Y h:i a', strtotime($details->created_at))); ?>

                                                                                </td>
                                                                                <td>
                                                                                    <?php if($details->status == 'disabled'): ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-danger btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php else: ?>
                                                                                        <a href="<?php echo e(url('course_details_status_update', [
                                                                                            'details_id' => $details->id,
                                                                                            'status' => $details->status,
                                                                                            'course_id' => $data->course_id,
                                                                                        ])); ?>"
                                                                                            class="btn btn-sm btn-success btn-block"><?php echo e($details->status); ?></a>
                                                                                    <?php endif; ?>
                                                                                </td>
                                                                            <?php endif; ?>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="collapse" id="collapseExampleexam<?php echo e($data->id); ?>">
                                                    <div class="card card-body">
                                                        <div class="table table-responsive">
                                                            <table class="table table-striped table-hover">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Title</th>
                                                                        <th>Created At</th>
                                                                        <th>Status</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $data->course_quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td>
                                                                                <button type="button"
                                                                                    class="btn btn-link btn-sm btn-block"
                                                                                    data-toggle="modal"
                                                                                    data-target="#exampleModal<?php echo e($quiz->id); ?>">
                                                                                    <?php echo e($quiz->quiz_title); ?>

                                                                                </button>

                                                                                <!-- Modal -->
                                                                                <div class="modal fade"
                                                                                    id="exampleModal<?php echo e($quiz->id); ?>"
                                                                                    tabindex="-1" role="dialog"
                                                                                    aria-labelledby="exampleModalLabel"
                                                                                    aria-hidden="true">
                                                                                    <div class="modal-dialog"
                                                                                        role="document">
                                                                                        <div class="modal-content">
                                                                                            <div class="modal-header">
                                                                                                <h5 class="modal-title"
                                                                                                    id="exampleModalLabel">
                                                                                                    <?php echo e($quiz->quiz_title); ?>

                                                                                                </h5>
                                                                                                <button type="button"
                                                                                                    class="close"
                                                                                                    data-dismiss="modal"
                                                                                                    aria-label="Close">
                                                                                                    <span
                                                                                                        aria-hidden="true">&times;</span>
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="modal-body">
                                                                                                <?php $__currentLoopData = $quiz->quiz_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <div class="card"
                                                                                                        style="margin-bottom: 20px;">
                                                                                                        <div
                                                                                                            class="card-header">
                                                                                                            <?php if($question->question_type != 'Matching Type'): ?>
                                                                                                                Question:
                                                                                                                <?php echo e($question->question); ?>

                                                                                                            <?php else: ?>
                                                                                                                Matching
                                                                                                                Type
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-body">
                                                                                                            <?php if($question->question_type == 'Enumeration'): ?>
                                                                                                                <?php
                                                                                                                    $explode = explode('|', $question->answer);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answers
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $explode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($value); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Multitple Choice'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>
                                                                                                                    <?php if($question->answer == 'choice_a'): ?>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->quiz_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->quiz_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->quiz_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->quiz_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_b'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->quiz_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->quiz_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->quiz_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->quiz_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_c'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->quiz_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->quiz_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->quiz_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->quiz_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_d'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->quiz_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->quiz_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->quiz_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->quiz_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php endif; ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Identification'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        <?php echo e($question->answer); ?>

                                                                                                                    </li>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Matching Type'): ?>
                                                                                                                <?php
                                                                                                                    $match_answer = explode('|', $question->answer);
                                                                                                                    $match_question = explode('|', $question->question);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answer
                                                                                                                    </li>

                                                                                                                    <?php for($i = 0; $i < count($match_answer); $i++): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_question[$i]); ?>

                                                                                                                            -
                                                                                                                            <?php echo e($match_answer[$i]); ?>

                                                                                                                        </li>
                                                                                                                    <?php endfor; ?>
                                                                                                                </ul>
                                                                                                                <br />
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $question->quiz_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_choices->choices); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-footer">
                                                                                                            <a href="<?php echo e(url('instructor_edit_quiz_question', ['question_id' => $question->id])); ?>"
                                                                                                                class="btn btn-primary btn-sm float-right">Edit</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </div>
                                                                                            <div class="modal-footer">
                                                                                                <button type="button"
                                                                                                    class="btn btn-sm btn-secondary"
                                                                                                    data-dismiss="modal">Close</button>
                                                                                                <a href="<?php echo e(url('instructor_add_item_to_quiz', ['quiz_id' => $quiz->id])); ?>"
                                                                                                    class="btn btn-sm btn-primary">Quiz
                                                                                                    (+)
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td><?php echo e(date('F j, Y h:i a', strtotime($quiz->created_at))); ?>

                                                                            </td>
                                                                            <td>
                                                                                <?php if($quiz->status == 'disabled'): ?>
                                                                                    <a href="<?php echo e(url('course_quiz_status_update', [
                                                                                        'quiz_id' => $quiz->id,
                                                                                        'status' => $quiz->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-danger btn-block"><?php echo e($quiz->status); ?></a>
                                                                                <?php else: ?>
                                                                                    <a href="<?php echo e(url('course_quiz_status_update', [
                                                                                        'quiz_id' => $quiz->id,
                                                                                        'status' => $quiz->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-success btn-block"><?php echo e($quiz->status); ?></a>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $data->exam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td>
                                                                                <!-- Button trigger modal -->
                                                                                <button type="button"
                                                                                    class="btn btn-link btn-sm btn-block"
                                                                                    data-toggle="modal"
                                                                                    data-target="#exampleModalexam<?php echo e($exam->id); ?>">
                                                                                    <?php echo e($exam->title); ?>

                                                                                </button>

                                                                                <!-- Modal -->
                                                                                <div class="modal fade"
                                                                                    id="exampleModalexam<?php echo e($exam->id); ?>"
                                                                                    tabindex="-1" role="dialog"
                                                                                    aria-labelledby="exampleModalLabel"
                                                                                    aria-hidden="true">
                                                                                    <div class="modal-dialog"
                                                                                        role="document">
                                                                                        <div class="modal-content">
                                                                                            <div class="modal-header">
                                                                                                <h5 class="modal-title"
                                                                                                    id="exampleModalLabel">
                                                                                                    <?php echo e($exam->title); ?>

                                                                                                </h5>
                                                                                                <button type="button"
                                                                                                    class="close"
                                                                                                    data-dismiss="modal"
                                                                                                    aria-label="Close">
                                                                                                    <span
                                                                                                        aria-hidden="true">&times;</span>
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="modal-body">
                                                                                                <?php $__currentLoopData = $exam->exam_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <div class="card"
                                                                                                        style="margin-bottom: 20px;">
                                                                                                        <div
                                                                                                            class="card-header">
                                                                                                            <?php if($question->question_type != 'Matching Type'): ?>
                                                                                                                Question:
                                                                                                                <?php echo e($question->question); ?>

                                                                                                            <?php else: ?>
                                                                                                                Matching
                                                                                                                Type
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-body">
                                                                                                            <?php if($question->question_type == 'Enumeration'): ?>
                                                                                                                <?php
                                                                                                                    $explode = explode('|', $question->answer);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answers
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $explode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($value); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Multitple Choice'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>

                                                                                                                    <?php if($question->answer == 'choice_a'): ?>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            A.
                                                                                                                            
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_b'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->exam_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->exam_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->exam_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_c'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->exam_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->exam_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->exam_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_d'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->exam_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->exam_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->exam_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->exam_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php endif; ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Identification'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        <?php echo e($question->answer); ?>

                                                                                                                    </li>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Matching Type'): ?>
                                                                                                                <?php
                                                                                                                    $match_answer = explode('|', $question->answer);
                                                                                                                    $match_question = explode('|', $question->question);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answer
                                                                                                                    </li>

                                                                                                                    <?php for($i = 0; $i < count($match_answer); $i++): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_question[$i]); ?>

                                                                                                                            -
                                                                                                                            <?php echo e($match_answer[$i]); ?>

                                                                                                                        </li>
                                                                                                                    <?php endfor; ?>
                                                                                                                </ul>
                                                                                                                <br />
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $question->exam_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_choices->choices); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-footer">
                                                                                                            <a href="<?php echo e(url('instructor_edit_exam_question', ['question_id' => $question->id])); ?>"
                                                                                                                class="btn btn-primary btn-sm float-right">Edit</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </div>
                                                                                            <div class="modal-footer">
                                                                                                <button type="button"
                                                                                                    class="btn btn-sm btn-secondary"
                                                                                                    data-dismiss="modal">Close</button>
                                                                                                <a href="<?php echo e(url('instructor_add_item_to_exam', ['exam_id' => $exam->id])); ?>"
                                                                                                    class="btn btn-sm btn-primary">Exam
                                                                                                    (+)
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td><?php echo e(date('F j, Y h:i a', strtotime($exam->created_at))); ?>

                                                                            </td>
                                                                            <td>
                                                                                <?php if($exam->status == 'disabled'): ?>
                                                                                    <a href="<?php echo e(url('course_exam_status_update', [
                                                                                        'exam_id' => $exam->id,
                                                                                        'status' => $exam->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-danger btn-block"><?php echo e($exam->status); ?></a>
                                                                                <?php else: ?>
                                                                                    <a href="<?php echo e(url('course_exam_status_update', [
                                                                                        'exam_id' => $exam->id,
                                                                                        'status' => $exam->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-success btn-block"><?php echo e($exam->status); ?></a>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    <?php $__currentLoopData = $data->assignment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td>
                                                                                <!-- Button trigger modal -->
                                                                                <button type="button"
                                                                                    class="btn btn-link btn-sm btn-block"
                                                                                    data-toggle="modal"
                                                                                    data-target="#exampleModalexam<?php echo e($assignment->id); ?>">
                                                                                    <?php echo e($assignment->title); ?>

                                                                                </button>

                                                                                <!-- Modal -->
                                                                                <div class="modal fade"
                                                                                    id="exampleModalexam<?php echo e($assignment->id); ?>"
                                                                                    tabindex="-1" role="dialog"
                                                                                    aria-labelledby="exampleModalLabel"
                                                                                    aria-hidden="true">
                                                                                    <div class="modal-dialog"
                                                                                        role="document">
                                                                                        <div class="modal-content">
                                                                                            <div class="modal-header">
                                                                                                <h5 class="modal-title"
                                                                                                    id="exampleModalLabel">
                                                                                                    <?php echo e($assignment->title); ?>

                                                                                                </h5>
                                                                                                <button type="button"
                                                                                                    class="close"
                                                                                                    data-dismiss="modal"
                                                                                                    aria-label="Close">
                                                                                                    <span
                                                                                                        aria-hidden="true">&times;</span>
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="modal-body">
                                                                                                <?php $__currentLoopData = $assignment->assignment_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <div class="card"
                                                                                                        style="margin-bottom: 20px;">
                                                                                                        <div
                                                                                                            class="card-header">
                                                                                                            <?php if($question->question_type != 'Matching Type'): ?>
                                                                                                                Question:
                                                                                                                <?php echo e($question->question); ?>

                                                                                                            <?php else: ?>
                                                                                                                Matching
                                                                                                                Type
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-body">
                                                                                                            <?php if($question->question_type == 'Enumeration'): ?>
                                                                                                                <?php
                                                                                                                    $explode = explode('|', $question->answer);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answers
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $explode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($value); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Multitple Choice'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>

                                                                                                                    <?php if($question->answer == 'choice_a'): ?>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            A.
                                                                                                                            
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_b'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->assignment_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->assignment_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->assignment_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_c'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->assignment_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->assignment_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->assignment_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php elseif($question->answer == 'choice_d'): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            A.
                                                                                                                            <?php echo e($question->assignment_details->choice_a); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            B.
                                                                                                                            <?php echo e($question->assignment_details->choice_b); ?>

                                                                                                                        </li>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            C.
                                                                                                                            <?php echo e($question->assignment_details->choice_c); ?>

                                                                                                                        </li>
                                                                                                                        <li class="list-group-item"
                                                                                                                            style="background-color:greenyellow">
                                                                                                                            D.
                                                                                                                            <?php echo e($question->assignment_details->choice_d); ?>

                                                                                                                        </li>
                                                                                                                    <?php endif; ?>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Identification'): ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        <?php echo e($question->answer); ?>

                                                                                                                    </li>
                                                                                                                </ul>
                                                                                                            <?php elseif($question->question_type == 'Matching Type'): ?>
                                                                                                                <?php
                                                                                                                    $match_answer = explode('|', $question->answer);
                                                                                                                    $match_question = explode('|', $question->question);
                                                                                                                ?>
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Answer
                                                                                                                    </li>

                                                                                                                    <?php for($i = 0; $i < count($match_answer); $i++): ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_question[$i]); ?>

                                                                                                                            -
                                                                                                                            <?php echo e($match_answer[$i]); ?>

                                                                                                                        </li>
                                                                                                                    <?php endfor; ?>
                                                                                                                </ul>
                                                                                                                <br />
                                                                                                                <ul
                                                                                                                    class="list-group">
                                                                                                                    <li
                                                                                                                        class="list-group-item">
                                                                                                                        Choices
                                                                                                                    </li>
                                                                                                                    <?php $__currentLoopData = $question->assignment_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                        <li
                                                                                                                            class="list-group-item">
                                                                                                                            <?php echo e($match_choices->choices); ?>

                                                                                                                        </li>
                                                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                                </ul>
                                                                                                            <?php endif; ?>
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="card-footer">
                                                                                                            <a href="<?php echo e(url('instructor_edit_assignment_question', ['question_id' => $question->id])); ?>"
                                                                                                                class="btn btn-primary btn-sm float-right">Edit</a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                            </div>
                                                                                            <div class="modal-footer">
                                                                                                <button type="button"
                                                                                                    class="btn btn-sm btn-secondary"
                                                                                                    data-dismiss="modal">Close</button>
                                                                                                <a href="<?php echo e(url('instructor_add_item_to_assignment', ['assignment_id' => $assignment->id])); ?>"
                                                                                                    class="btn btn-sm btn-primary">Assignment
                                                                                                    (+)
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                            <td><?php echo e(date('F j, Y h:i a', strtotime($assignment->created_at))); ?>

                                                                            </td>
                                                                            <td>
                                                                                <?php if($assignment->status == 'disabled'): ?>
                                                                                    <a href="<?php echo e(url('instructor_course_assignment_status_update', [
                                                                                        'assignment_id' => $assignment->id,
                                                                                        'status' => $assignment->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-danger btn-block"><?php echo e($assignment->status); ?></a>
                                                                                <?php else: ?>
                                                                                    <a href="<?php echo e(url('instructor_course_assignment_status_update', [
                                                                                        'assignment_id' => $assignment->id,
                                                                                        'status' => $assignment->status,
                                                                                        'course_id' => $data->course_id,
                                                                                    ])); ?>"
                                                                                        class="btn btn-sm btn-success btn-block"><?php echo e($assignment->status); ?></a>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-12" style="margin-bottom: 10px;">
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary btn-sm btn-block"
                                            data-toggle="modal" data-target="#exampleModalcontent<?php echo e($data->id); ?>">
                                            ADD CHAPTER CONTENT
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModalcontent<?php echo e($data->id); ?>"
                                            tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                            aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(route('instructor_add_file_to_chapter')); ?>"
                                                        enctype="multipart/form-data" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <label>File</label>
                                                            <input type="file" class="form-control" name="file"
                                                                required>

                                                            <input type="hidden" name="course_id"
                                                                value="<?php echo e($data->course_id); ?>">
                                                            <input type="hidden" name="chapter_id"
                                                                value="<?php echo e($data->id); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-sm btn-secondary"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Save
                                                                changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary btn-sm btn-block"
                                            data-toggle="modal" data-target="#exampleModaledit<?php echo e($data->id); ?>">
                                            EDIT
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModaledit<?php echo e($data->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Edit</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <form action="<?php echo e(route('instructor_edit_chapter')); ?>"
                                                        enctype="multipart/form-data" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-body">
                                                            <label>Chapter</label>
                                                            <input type="text" name="chapter" class="form-control"
                                                                required value="<?php echo e($data->chapter_number); ?>">

                                                            <label>Title</label>
                                                            <input type="text" name="title" class="form-control"
                                                                required value="<?php echo e($data->title); ?>">

                                                            <label>Description</label>
                                                            <textarea name="content" class="form-control" col="30"><?php echo e($data->content); ?></textarea>

                                                            <input type="hidden" name="course_id"
                                                                value="<?php echo e($data->course_id); ?>">
                                                            <input type="hidden" name="chapter_id"
                                                                value="<?php echo e($data->id); ?>">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-sm btn-secondary"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-sm btn-primary">Save
                                                                changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">Comments</div>
        <div class="card-body">
            <?php $__currentLoopData = $course->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="margin-bottom: 10px;">
                    <div class="card-header"><?php echo e($comments->user->last_name); ?> <?php echo e($comments->user->name); ?></div>
                    <div class="card-body"><?php echo e($comments->comment); ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <form action="<?php echo e(route('instructor_comment_process')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label>Add Comment</label>
                <textarea name="comment" class="form-control" required></textarea>
                <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>">
                <br />
                <button class="btn btn-primary btn-sm float-right">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_show_chapter.blade.php ENDPATH**/ ?>