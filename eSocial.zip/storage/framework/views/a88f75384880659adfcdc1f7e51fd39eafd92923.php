

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('instructor_edit_exam_question_process')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <a href="<?php echo e(url('instructor_show_chapter',$question->course_id)); ?>" class="btn btn-sm btn-primary">Back</a>
      
        <br /><br />
        <div class="card">
            <div class="card-header">
                <?php if($question->question_type != 'Matching Type'): ?>
                    Question:
                    <textarea name="question" class="form-control" required><?php echo e($question->question); ?></textarea>
                <?php else: ?>
                    Matching Type
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if($question->question_type == 'Enumeration'): ?>
                    <?php
                        $explode = explode('|', $question->answer);
                    ?>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Answers
                        </li>
                        <?php $__currentLoopData = $explode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <input type="text" class="form-control" name="answer[]" required
                                    value="<?php echo e($value); ?>">
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php elseif($question->question_type == 'Multitple Choice'): ?>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <label>Answer</label>
                            <select name="answer" class="form-control" required>
                                <option value="" default>Set Answer</option>
                                <option value="choice_a">Choice A</option>
                                <option value="choice_b">Choice B</option>
                                <option value="choice_c">Choice C</option>
                                <option value="choice_d">Choice D</option>
                                <option value="<?php echo e($question->answer); ?>" selected><?php echo e(str_replace('_',' ',$question->answer)); ?></option>
                            </select>
                        </li>
                        <li class="list-group-item">
                            Choices</li>
                    
                        <li class="list-group-item">
                            A.
                            <input type="text" name="choice_a" value="<?php echo e($question->quiz_details->choice_a); ?>" required
                                class="form-control">
                        </li>
                        <li class="list-group-item">
                            B.
                            <input type="text" name="choice_b" value="<?php echo e($question->quiz_details->choice_b); ?>" required
                                class="form-control">
                        </li>
                        <li class="list-group-item">
                            C.
                            <input type="text" name="choice_c" value="<?php echo e($question->quiz_details->choice_c); ?>" required
                                class="form-control">
                        </li>
                        <li class="list-group-item">
                            D.
                            <input type="text" name="choice_d" value="<?php echo e($question->quiz_details->choice_d); ?>" required
                                class="form-control">
                        </li>
                    </ul>
                    <input type="hidden" name="quiz_details_id" value="<?php echo e($question->quiz_details->id); ?>">
                <?php elseif($question->question_type == 'Identification'): ?>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <input type="text" class="form-control" name="answer" required value="<?php echo e($question->answer); ?>">
                        </li>
                    </ul>
                <?php elseif($question->question_type == 'Matching Type'): ?>
                    <?php
                        $match_answer = explode('|', $question->answer);
                        $match_question = explode('|', $question->question);
                    ?>
                    <ul class="list-group">
                        <li class="list-group-item">
                            Answer</li>

                        <?php for($i = 0; $i < count($match_answer); $i++): ?>
                            <li class="list-group-item">
                                <div class="row">
                                    <div class="col-md-6">
                                        <input type="text" value="<?php echo e($match_question[$i]); ?>" name="question[]"
                                            class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" value="<?php echo e($match_answer[$i]); ?>" name="answer[]"
                                            class="form-control" required>
                                    </div>
                                </div>
                            </li>
                        <?php endfor; ?>
                    </ul>
                    <br />
                    <ul class="list-group">
                        <li class="list-group-item">Choices</li>
                        <?php $__currentLoopData = $question->quiz_matching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match_choices): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <input type="text" value="<?php echo e($match_choices->choices); ?>" name="choices[<?php echo e($match_choices->id); ?>]" required
                                    class="form-control">
                                <input type="hidden" name="matching_id[]" value="<?php echo e($match_choices->id); ?>">
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <input type="hidden" value="<?php echo e($question->course_id); ?>" name="course_id">
                <input type="hidden" value="<?php echo e($question->id); ?>" name="quiz_question_id">
                <input type="hidden" value="<?php echo e($question->course_chapter_id); ?>" name="course_chapter_id">
                <input type="hidden" value="<?php echo e($question->question_type); ?>" name="question_type">
                <button class="float-right btn btn-sm btn-primary">Submit</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_edit_exam_question.blade.php ENDPATH**/ ?>