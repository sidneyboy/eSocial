

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session('success')): ?>
                <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger border-left-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="card" style="width: 100%;">
                <div class="card-header" style="font-weight: bold;">Course Chapter</div>
                <form action="<?php echo e(route('instructor_add_course_phase_2_process')); ?>" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Chapter #</label>
                            <input type="text" name="chapter_number" class="form-control" required>

                            <label>Title</label>
                            <input type="text" name="title" class="form-control" required>

                            <label>Topic</label>
                            <textarea name="content" class="form-control" required></textarea>
                            

                            <label>Thumbnail</label>
                            <input type="file" name="thumbnail" accept="image/*" class="form-control" required>

                            <input type="hidden" value="<?php echo e($course_id); ?>" name="course_id">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-sm btn-primary float-right">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/instructor_add_course_phase_2.blade.php ENDPATH**/ ?>