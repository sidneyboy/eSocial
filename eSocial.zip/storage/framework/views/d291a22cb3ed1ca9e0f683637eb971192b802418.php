

<?php $__env->startSection('main-content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">Instructor Posted Courses</div>
        <div class="card-body">
            <div class="table table-responsive">
                <table class="table table-striped table-hover table-sm" id="example">
                    <thead>
                        <tr>
                            <th>Course Type</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Monitization Free</th>
                            <th>Instructor</th>
                            <th>Created at</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($data->course_type->course_type); ?></td>
                                <td><?php echo e($data->course_title); ?></td>
                                <td><?php echo e($data->course_description); ?></td>
                                <td><?php echo e($data->course_description); ?></td>
                                <td><?php echo e($data->user->last_name); ?> <?php echo e($data->user->name); ?></td>
                                <td><?php echo e(date('F j, Y ', strtotime($data->created_at))); ?></td>
                                <td>
                                    <?php if($data->status == 'Pending Approval'): ?>
                                        <a href="<?php echo e(url('course_update', ['course_id' => $data->id, 'status' => $data->status])); ?>"
                                            class="btn btn-sm btn-warning btn-block"><?php echo e($data->status); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('course_update', ['course_id' => $data->id, 'status' => $data->status])); ?>"
                                            class="btn btn-sm btn-success btn-block"><?php echo e($data->status); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\GitHub\eSocial\resources\views/courses.blade.php ENDPATH**/ ?>